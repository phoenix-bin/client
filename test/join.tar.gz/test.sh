if [ -z "$1" ] 
  then echo -e "Zookeeper not specified. \nUsage: test.sh <zookeeper>";
  exit;
fi

./psql.sh $1 DDL.sql
./psql.sh $1 LHS5M.csv
./psql.sh $1 RHS500K.csv
./psql.sh $1 QRY.sql

