select count(*) from LHS5M JOIN RHS500K on RHS500K.mypk = LHS5M.column1;
