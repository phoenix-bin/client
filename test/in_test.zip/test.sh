if [ -z "$1" ] 
  then echo -e "Zookeeper not specified. \nUsage: test.sh <zookeeper>";
  exit;
fi

./psql.sh $1 DDL.sql
./psql.sh $1 T.csv
./psql.sh $1 QUERY.sql

