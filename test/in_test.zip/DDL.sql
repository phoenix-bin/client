CREATE TABLE IF NOT EXISTS T (mypk CHAR(10) NOT NULL PRIMARY KEY,CF.column1 char(10),CF.column2 char(10),CF.column3 char(10));
